document.addEventListener('DOMContentLoaded', () => {
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    
    document.getElementById('endDate').value = today.toISOString().split('T')[0];
    document.getElementById('startDate').value = firstDay.toISOString().split('T')[0];

    // Load saved settings
    chrome.storage.local.get(['semManagerUrl', 'semManagerToken'], (data) => {
        if (data.semManagerUrl) document.getElementById('apiUrl').value = data.semManagerUrl;
        if (data.semManagerToken) document.getElementById('apiToken').value = data.semManagerToken;
    });
});

document.getElementById('calcBtn').addEventListener('click', () => {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const targetUserId = document.getElementById('targetUserId').value.trim();  
    const btn = document.getElementById('calcBtn');
    const loading = document.getElementById('loading');
    const resultsDiv = document.getElementById('results');

    if (!startDate || !endDate) {
        resultsDiv.innerHTML = '<p class="error-msg">Please select both dates.</p>';
        return;
    }

    btn.disabled = true;
    loading.classList.remove('hidden');
    resultsDiv.innerHTML = '';

    
    chrome.tabs.query({ url: "*://*.codetantra.com/*" }, function(tabs) {
        if (tabs.length === 0) {
            btn.disabled = false;
            loading.classList.add('hidden');
            resultsDiv.innerHTML = '<p class="error-msg">Please open your CodeTantra portal in another tab first.</p>';
            return;
        }

        
        const ctTab = tabs[0];
        chrome.tabs.sendMessage(ctTab.id, {
            action: "calculate",
            start: startDate,
            end: endDate,
            targetUserId: targetUserId
        }, (response) => {
            btn.disabled = false;
            loading.classList.add('hidden');

            if (chrome.runtime.lastError) {
                resultsDiv.innerHTML = '<p class="error-msg">Please refresh your CodeTantra tab and try again.</p>';
                return;
            }

            if (response && response.status === "success") {
                displayResults(response.data);
                // Auto-sync to Semester Manager if configured
                syncToSemesterManager(response.data);
            } else {
                resultsDiv.innerHTML = `<p class="error-msg">Error: ${response ? response.message : "Failed to fetch."}</p>`;
            }
        });
    });
});

// Save settings button
document.getElementById('saveSettings').addEventListener('click', () => {
    const apiUrl = document.getElementById('apiUrl').value.trim();
    const apiToken = document.getElementById('apiToken').value.trim();
    
    chrome.storage.local.set({ semManagerUrl: apiUrl, semManagerToken: apiToken }, () => {
        const statusEl = document.getElementById('syncStatus');
        statusEl.textContent = '✅ Settings saved!';
        statusEl.className = 'sync-status success';
        setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'sync-status'; }, 3000);
    });
});

async function syncToSemesterManager(data) {
    const statusEl = document.getElementById('syncStatus');
    
    const stored = await new Promise(resolve => {
        chrome.storage.local.get(['semManagerUrl', 'semManagerToken'], resolve);
    });

    const apiUrl = stored.semManagerUrl;
    const apiToken = stored.semManagerToken;

    if (!apiUrl || !apiToken) {
        statusEl.textContent = 'ℹ️ Configure API settings to auto-sync';
        statusEl.className = 'sync-status info';
        return;
    }

    statusEl.textContent = '🔄 Syncing to Semester Manager...';
    statusEl.className = 'sync-status info';

    try {
        const response = await fetch(`${apiUrl}/api/subjects/attendance/sync`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiToken}`,
            },
            body: JSON.stringify({ attendanceData: data }),
        });

        if (!response.ok) {
            throw new Error(`Server returned ${response.status}`);
        }

        const result = await response.json();
        statusEl.textContent = `✅ Synced ${result.results?.length || 0} subjects to Semester Manager!`;
        statusEl.className = 'sync-status success';
    } catch (error) {
        statusEl.textContent = `❌ Sync failed: ${error.message}`;
        statusEl.className = 'sync-status error';
    }
}

function displayResults(data) {
    const resultsDiv = document.getElementById('results');
    
    if (data.error) {
        resultsDiv.innerHTML = `<p class="error-msg">${data.error}</p>`;
        return;
    }

    const subjects = Object.keys(data);
    if (subjects.length === 0) {
        resultsDiv.innerHTML = '<p>No classes found in this date range.</p>';
        return;
    }

    let html = '';
    subjects.forEach(subject => {
        const stats = data[subject];
        const percentage = stats.total > 0 ? ((stats.attended / stats.total) * 100).toFixed(2) : 0;
        
        
        let missedHtml = '';
        if (stats.missedDates && stats.missedDates.length > 0) {
            missedHtml = `<div class="missed-dates"><strong>Missed:</strong> ${stats.missedDates.join(', ')}</div>`;
        }

        const barColor = percentage >= 75 ? '#10B981' : percentage >= 60 ? '#F59E0B' : '#EF4444';
        
        html += `
            <div class="subject-card">
                <div class="subject-title">${subject}</div>
                <div class="subject-stats">
                    Attended: ${stats.attended} / ${stats.total} <br>
                    <strong>Percentage: ${percentage}%</strong>
                    <div class="attendance-bar">
                        <div class="attendance-bar-fill" style="width: ${percentage}%; background: ${barColor}"></div>
                    </div>
                    ${missedHtml}
                </div>
            </div>
        `;
    });

    resultsDiv.innerHTML = html;
}